function pesquisar() { const input = document.getElementById("search").value.toLowerCase();
     const itens = document.querySelectorAll("#lista li"); 
     itens.forEach(function(item) 
     { const texto = item.textContent.toLowerCase();
         if (texto.includes(input)) { item.style.display = ""; }
          else { item.style.display = "none"; } }); }